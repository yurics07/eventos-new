package com.senai.eventsmanager.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class AvisoSwagger implements CommandLineRunner {

    @Override
    public void run(String... args) {
        System.out.println("\u001B[31m==============================\u001B[0m");
        System.out.println("\u001B[31mLINK DO SWAGGER:\u001B[0m \u001B[33mhttp://localhost:8080/swagger-ui/index.html\u001B[0m");
        System.out.println("\u001B[31m==============================\u001B[0m");
    }


}
