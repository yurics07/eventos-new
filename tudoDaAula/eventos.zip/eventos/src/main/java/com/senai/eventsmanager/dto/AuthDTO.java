package com.senai.eventsmanager.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
public class AuthDTO {

    @NotBlank(message = "A senha e obrigatoria")
    private String senha;

    @NotBlank(message = "O email e obrigatorio")
    private String email;
}
