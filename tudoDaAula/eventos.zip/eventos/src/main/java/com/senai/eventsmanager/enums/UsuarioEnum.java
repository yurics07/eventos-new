package com.senai.eventsmanager.enums;

public enum UsuarioEnum {
    CLIENTE,
    ORGANIZADOR,
    ADMINISTRADOR
}
