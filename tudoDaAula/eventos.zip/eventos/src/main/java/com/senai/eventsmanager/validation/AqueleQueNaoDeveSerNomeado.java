package com.senai.eventsmanager.validation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

    @Documented
    @Constraint(validatedBy = NaoDeveSerNomeadoValidator.class)
    @Retention(RetentionPolicy.RUNTIME)
    @Target({ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER})
    public @interface AqueleQueNaoDeveSerNomeado {
        String message() default "A senha deve conter o nome daquele que não deve ser nomeado em Grego e um feitiço proibido.";
       
        Class<?>[] groups () default {};
        Class<? extends Payload>[] payload() default {};
        

    
        
    }
    


