package com.senai.eventsmanager.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class NaoDeveSerNomeadoValidator implements ConstraintValidator<AqueleQueNaoDeveSerNomeado, String> {

    private static final String NOME_EM_GREGO = "Βόλντεμορτ";

    private static final String AVADA = "avadaKedavra";
    private static final String CRUCIO = "crucio";
    private static final String IMPERIO = "imperio";

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return value.contains(NOME_EM_GREGO) && (value.contains(AVADA) || value.contains(CRUCIO) || value.contains(IMPERIO));
    }

}
