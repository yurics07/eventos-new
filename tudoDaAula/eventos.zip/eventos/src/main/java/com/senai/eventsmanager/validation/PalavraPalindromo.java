package com.senai.eventsmanager.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class PalavraPalindromo implements ConstraintValidator<DeveTerPalavraPalindromo, String> {

    private static final int MIN_TAMANHO = 5;

    public boolean ehPalindromo(String palavra) {
        String invertida = new StringBuilder(palavra).reverse().toString();
        return palavra.equalsIgnoreCase(invertida);
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null || value.length() < MIN_TAMANHO) {
            return false;
        }

        int n = value.length();

        for (int i = 0; i < n; i++) {
            for (int j = i + MIN_TAMANHO; j <= n; j++) {
                String sub = value.substring(i, j);
                if (ehPalindromo(sub)) {
                    return true;
                }
            }
        }
        return false;
    }
}
