package com.senai.eventsmanager.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class TemHolanda implements ConstraintValidator<HolandaFinlandes, String>{

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {

        return value.toLowerCase().contains("alankomaat");
    }

}
