package com.senai.eventsmanager.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class TemSalmoValidador implements ConstraintValidator<DeveTerSalmo, String> {

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        String lowerValue = value.toLowerCase();
        return lowerValue.contains("porque") && lowerValue.contains("rosto");
    }
}
