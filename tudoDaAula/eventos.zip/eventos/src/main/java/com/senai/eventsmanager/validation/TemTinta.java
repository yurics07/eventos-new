package com.senai.eventsmanager.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class TemTinta implements ConstraintValidator<TintaAmarela, String> {

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        String lowerValue = value.toLowerCase();
        return lowerValue.contains("vincent van gogh");
    }

 
}