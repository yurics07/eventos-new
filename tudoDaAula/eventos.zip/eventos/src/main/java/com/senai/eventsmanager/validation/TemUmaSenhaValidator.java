package com.senai.eventsmanager.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class TemUmaSenhaValidator implements ConstraintValidator<DeveTerUmaSenha, String> {

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
    
        return value.contains("senha");

    }


}
