package com.senai.eventsmanager.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class TemVogalValidador implements ConstraintValidator<DeveTerVogal, String> {

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {
    String ultimas5 = value.substring(value.length() - 5).toLowerCase();

    return ultimas5.matches("[aeiou]{5}");
  }
}
